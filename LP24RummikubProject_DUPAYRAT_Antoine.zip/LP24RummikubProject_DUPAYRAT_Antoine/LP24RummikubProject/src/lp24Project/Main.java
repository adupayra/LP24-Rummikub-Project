package lp24Project;


public class Main {
	
	public static void main(String[] args)
	{	
		GameManager.INSTANCE.start();
	}

}
